
/*
 * Luis Miguel García Sevilla 1º DAM Tarde.
 * Este programa muestra un dibujo de un monitor.
*/

public class Ej9 {
    public static void main(String[] args) {
        System.out.printf("%80s","\033[97m██████████████████████████████████████████████████\n");
        System.out.printf("%25s %49s","█","█\n");
        System.out.printf("%50s %24s","█ public class HolaMundo {","█\n");
        System.out.printf("%70s %4s","█     public static void main(String[] args) {","█\n");
        System.out.printf("%66s %8s","█        System.out.println('Hola Mundo');","█\n");
        System.out.printf("%30s %44s","█    }","█\n");
        System.out.printf("%27s %47s","█ }","█\n");
        System.out.printf("%25s %49s","█","█\n");
        System.out.printf("%72s %1s","█ ----------------------------------------------","█\n");
        System.out.printf("%39s %35s","█    Hola Mundo","█\n");
        System.out.printf("%25s %49s","█","█\n");
        System.out.printf("%75s","██████████████████████████████████████████████████\n");
        System.out.printf("%54s","████████\n");
        System.out.printf("%58s","████████████████\n");
        System.out.printf("%70s","████████████████████████████████████████\n");
        }
}