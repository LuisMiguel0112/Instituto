
/*
 * Luis Miguel García Sevilla 1º DAM Tarde.
 * Este programa muestra una piramide hueca.
*/

public class Ej7 {
    public static void main(String[] args) {
        System.out.printf("%11s","\033[34m*\n");
        System.out.printf("%4s %2s","*","*\n");
        System.out.printf("%3s %4S","*","*\n");
        System.out.printf("%2s %6s","*","*\n");
        System.out.printf("%1s","*********\n");
    }
}
